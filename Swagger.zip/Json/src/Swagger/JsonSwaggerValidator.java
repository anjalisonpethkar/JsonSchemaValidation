package Swagger;

import java.io.File;
import java.io.IOException;
import java.net.URI;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;


public class JsonSwaggerValidator {


	public static void main(final String[] args)
	        throws IOException, ProcessingException
	    {
		File JsonSchemafile = new File(args[0]);
		File JsonResponsefile = new File(args[1]);
		final URI uri = JsonSchemafile.toURI();
		JsonNode good = JsonLoader.fromFile(JsonResponsefile);
	
	        final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();

	        
	        final JsonSchema schema = factory.getJsonSchema(uri.toString());

	        ProcessingReport report;

	        report = schema.validate(good);
	        System.out.println(report);

		    }

	}
